wimboot -- Windows Imaging Format bootloader
============================================

See http://ipxe.org/wimboot for instructions.
